from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import uvicorn
import json
import uuid
import time
import datetime

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

session_db = {}
surveys_db = {}

survey_configs = {
    "default": {
        "allow_school_change": False, 
        "default_school": "Ambience Partner School",
        "time_limit_minutes": 30,
        "optional_questions": [1, 11]  # Example optional questions
    }
}

# --- ADMIN ROUTES ---
@app.get("/", response_class=HTMLResponse)
async def landing_page(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/admin-login", response_class=HTMLResponse)
async def admin_login_page(request: Request):
    return templates.TemplateResponse("admin_login.html", {"request": request})

@app.post("/admin-login")
async def process_admin_login():
    return RedirectResponse(url="/dashboard", status_code=303)

@app.get("/admin-register", response_class=HTMLResponse)
async def admin_register_page(request: Request):
    return templates.TemplateResponse("admin_register.html", {"request": request})

@app.post("/admin-register")
async def process_admin_register():
    return RedirectResponse(url="/admin-login", status_code=303)

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.post("/api/save_survey")
async def save_survey(request: Request):
    data = await request.json()
    survey_id = str(uuid.uuid4())[:8] 
    surveys_db[survey_id] = data
    base_url = str(request.base_url).rstrip('/')
    return JSONResponse(content={"status": "success", "survey_id": survey_id, "link": f"{base_url}/take-survey/{survey_id}"})


# --- STUDENT SURVEY FLOW ---

@app.get("/take-survey/{survey_id}")
async def take_survey(request: Request, survey_id: str):
    session_id = str(uuid.uuid4())
    session_db[session_id] = {
        "max_q": 0, 
        "current_q": 0, 
        "survey_id": survey_id,
        "start_time_unix": time.time(), # UNIVERSAL STOPWATCH START
        "start_date_str": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    return RedirectResponse(url=f"/consent/{session_id}", status_code=303)

@app.get("/consent/{session_id}", response_class=HTMLResponse)
async def consent_page(request: Request, session_id: str):
    return templates.TemplateResponse("consent.html", {"request": request, "session_id": session_id})

@app.get("/student-details/{session_id}", response_class=HTMLResponse)
async def student_details_page(request: Request, session_id: str):
    config = survey_configs["default"]
    return templates.TemplateResponse("student_details.html", {
        "request": request, 
        "session_id": session_id,
        "allow_school_change": config["allow_school_change"],
        "default_school": config["default_school"]
    })

@app.post("/submit-details/")
async def submit_details(
    session_id: str = Form(...),
    full_name: str = Form(...),
    dob: str = Form(...),
    grade: str = Form(...),
    school: str = Form(None),
    consent_given: str = Form(None)
):
    if session_id not in session_db:
        session_db[session_id] = {"max_q": 0}
        
    session_db[session_id]["student_info"] = {
        "full_name": full_name, "dob": dob, "grade": grade, "school": school, "consent": consent_given
    }
    return RedirectResponse(url=f"/instructions/{session_id}", status_code=303)

@app.get("/instructions/{session_id}", response_class=HTMLResponse)
async def instructions(request: Request, session_id: str):
    return templates.TemplateResponse("instructions.html", {"request": request, "session_id": session_id})

@app.get("/question/{session_id}/{q_id}", response_class=HTMLResponse)
async def get_question(request: Request, session_id: str, q_id: int):
    if session_id not in session_db:
        session_db[session_id] = {"max_q": 0}
        
    max_progress = session_db[session_id].get("max_q", 0)
    
    if q_id > max_progress:
        return RedirectResponse(url=f"/question/{session_id}/{max_progress}")
    
    # --- TRACK SET START TIMES (COUNTING UP) ---
    if q_id == 0 and "spatial_start" not in session_db[session_id]:
        session_db[session_id]["spatial_start"] = time.time()
    elif q_id == 11 and "mr_start" not in session_db[session_id]:
        session_db[session_id]["mr_start"] = time.time()
        
    saved_image = session_db[session_id].get("uploaded_image", "")
    saved_answer = session_db[session_id].get(f"q_{q_id}_answer", None)
    
    config = survey_configs["default"]
    
    timer_state = "running"
    time_to_send = 0
    
    # SEPARATE 30-MIN TIMERS
    
    # 1. Spatial Task Timer (Q1 - Q9)
    if 1 <= q_id <= 9:
        if "spatial_end_time" not in session_db[session_id]:
            session_db[session_id]["spatial_end_time"] = (time.time() + (config["time_limit_minutes"] * 60)) * 1000
        timer_state = "running"
        time_to_send = session_db[session_id].get("spatial_end_time", 0)
        
    # 2. Mental Rotation Instructions (Q10)
    elif q_id == 10:
        timer_state = "paused"
        # Shows a fresh "30:00 (Paused)" ready for the next section
        time_to_send = config["time_limit_minutes"] * 60 * 1000 
        
    # 3. Mental Rotation Task Timer (Q11 - Q20)
    elif 11 <= q_id <= 20:
        if "mr_end_time" not in session_db[session_id]:
            session_db[session_id]["mr_end_time"] = (time.time() + (config["time_limit_minutes"] * 60)) * 1000
        timer_state = "running"
        time_to_send = session_db[session_id].get("mr_end_time", 0)
        
    # Feedback questions (Q21-30) will simply pass time_to_send = 0
    
    is_optional = q_id in config.get("optional_questions", [])
    
    return templates.TemplateResponse(
        "next_question.html", 
        {
            "request": request, 
            "session_id": session_id, 
            "q_id": q_id,
            "saved_image": saved_image,
            "saved_answer": json.dumps(saved_answer) if saved_answer else "null",
            "time_to_send": time_to_send,
            "timer_state": timer_state,
            "is_optional": is_optional
        }
    )

@app.post("/submit_answer/")
async def submit_answer(
    session_id: str = Form(...), 
    q_id: int = Form(...), 
    answer_data: str = Form(...),
    image_data: str = Form(None)
):
    if session_id not in session_db:
        session_db[session_id] = {"max_q": 0}
        
    if answer_data == '"empty"':
        session_db[session_id][f"q_{q_id}_answer"] = "empty"
    else:
        session_db[session_id][f"q_{q_id}_answer"] = json.loads(answer_data) if answer_data else None
    
    if image_data:
        session_db[session_id]["uploaded_image"] = image_data
        
    # --- CALCULATE SET TOTAL TIMES ---
    if q_id == 9 and "spatial_start" in session_db[session_id]:
        session_db[session_id]["spatial_total_sec"] = round(time.time() - session_db[session_id]["spatial_start"], 2)
    elif q_id == 20 and "mr_start" in session_db[session_id]:
        session_db[session_id]["mr_total_sec"] = round(time.time() - session_db[session_id]["mr_start"], 2)
    
    current_max = session_db[session_id].get("max_q", 0)
    if q_id == current_max:
        session_db[session_id]["max_q"] = q_id + 1
        
    if q_id == 30:
        return RedirectResponse(url=f"/finish_survey/{session_id}", status_code=303)
        
    next_q = q_id + 1
    return RedirectResponse(url=f"/question/{session_id}/{next_q}", status_code=303)

@app.get("/finish_survey/{session_id}", response_class=HTMLResponse)
async def finish_survey(request: Request, session_id: str):
    if session_id in session_db:
        session_db[session_id]["complete"] = True
        
        end_time = time.time()
        session_db[session_id]["finish_time_unix"] = end_time
        session_db[session_id]["finish_date_str"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # UNIVERSAL STOPWATCH END
        if "start_time_unix" in session_db[session_id]:
            total_sec = end_time - session_db[session_id]["start_time_unix"]
            session_db[session_id]["total_elapsed_seconds"] = round(total_sec, 2)
            
    return templates.TemplateResponse("submitted.html", {"request": request})

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)