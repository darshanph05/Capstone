




from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import uvicorn
import json
import uuid

app = FastAPI()

# Mount the static directory to serve images, CSS, and JS files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Ensure you have a folder named 'templates' in the same directory as web.py
templates = Jinja2Templates(directory="templates")

# In-memory dictionary to mock a database for session progress (autosave)

session_db = {}

@app.get("/", response_class=HTMLResponse)
async def role_select(request: Request):
    """Landing page - role selection (Student or Researcher)"""
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/student-login", response_class=HTMLResponse)
async def student_login(request: Request):
    """Student login page"""
    return templates.TemplateResponse("student_login.html", {"request": request})

@app.get("/researcher-login", response_class=HTMLResponse)
async def researcher_login(request: Request):
    """Researcher login page"""
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/instructions", response_class=HTMLResponse)
async def instructions(request: Request):
    """Instructions page before starting the survey"""
    student_name = request.query_params.get("student_name", "")
    school_email = request.query_params.get("school_email", "")
    grade = request.query_params.get("grade", "")
    
    return templates.TemplateResponse("instructions.html", {
        "request": request,
        "student_name": student_name,
        "school_email": school_email,
        "grade": grade
    })

@app.get("/question/{q_id}", response_class=HTMLResponse)
async def get_question_start(request: Request, q_id: int):
    """Start a new session and redirect to the question with session_id"""
    session_id = str(uuid.uuid4())
    return RedirectResponse(url=f"/question/{session_id}/{q_id}", status_code=303)

@app.get("/question/{session_id}/{q_id}", response_class=HTMLResponse)
async def get_question(request: Request, session_id: str, q_id: int):
    # Initialize session if it doesn't exist
    if session_id not in session_db:
        session_db[session_id] = {"current_q": 1}

    current_progress = session_db[session_id].get("current_q", 1)
    
    # Enforce forward-only navigation: redirect to the current active question if they try to go back
    if q_id < current_progress:
        return RedirectResponse(url=f"/question/{session_id}/{current_progress}")
    
    # Render the single-screen interface
    return templates.TemplateResponse(
        "next_question.html", 
        {"request": request, "session_id": session_id, "q_id": q_id}
    )

@app.post("/submit_answer/")
async def submit_answer(
    session_id: str = Form(...), 
    q_id: int = Form(...), 
    answer_data: str = Form(...)
):
    if session_id not in session_db:
        session_db[session_id] = {}
    
    # Autosave the captured data (e.g., coordinates)
    session_db[session_id][f"q_{q_id}_answer"] = json.loads(answer_data) if answer_data else None
    
    # Increment progress state
    next_q = q_id + 1
    session_db[session_id]["current_q"] = next_q
    
    # Push the user to the next question
    return RedirectResponse(url=f"/question/{session_id}/{next_q}", status_code=303)

if __name__ == "__main__":
    # Run the server on localhost port 8000
    uvicorn.run(app, host="0.0.0.0", port=8000)