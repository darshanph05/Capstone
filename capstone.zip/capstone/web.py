from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def role_select():
    return render_template("login.html")

@app.route("/student-login")
def student_login():
    return render_template("student_login.html")

@app.route("/instructions")
def instructions():
    return render_template("instructions.html")

@app.route("/question/1")
def question():
    return render_template("survey.html")


@app.route("/submit")
def submit():
    return render_template("submit.html")

if __name__ == "__main__":
    app.run(debug=True)