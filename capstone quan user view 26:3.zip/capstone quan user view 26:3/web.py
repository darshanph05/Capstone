from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import uvicorn
import json
import uuid
import time

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

session_db = {}
surveys_db = {}

survey_configs = {
    "default": {
        "allow_school_change": False, 
        "default_school": "Ambience Partner School",
        "time_limit_minutes": 30
    }
}

# --- ADMIN ROUTES ---
@app.get("/", response_class=HTMLResponse)
async def landing_page(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/admin-login", response_class=HTMLResponse)
async def admin_login_page(request: Request):
    return templates.TemplateResponse("admin_login.html", {"request": request})

@app.post("/admin-login")
async def process_admin_login():
    return RedirectResponse(url="/dashboard", status_code=303)

@app.get("/admin-register", response_class=HTMLResponse)
async def admin_register_page(request: Request):
    return templates.TemplateResponse("admin_register.html", {"request": request})

@app.post("/admin-register")
async def process_admin_register():
    return RedirectResponse(url="/admin-login", status_code=303)

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.post("/api/save_survey")
async def save_survey(request: Request):
    data = await request.json()
    survey_id = str(uuid.uuid4())[:8] 
    surveys_db[survey_id] = data
    base_url = str(request.base_url).rstrip('/')
    return JSONResponse(content={"status": "success", "survey_id": survey_id, "link": f"{base_url}/take-survey/{survey_id}"})


# --- STUDENT SURVEY FLOW ---

@app.get("/take-survey/{survey_id}")
async def take_survey(request: Request, survey_id: str):
    session_id = str(uuid.uuid4())
    session_db[session_id] = {"max_q": 0, "current_q": 0, "survey_id": survey_id}
    return RedirectResponse(url=f"/consent/{session_id}", status_code=303)

@app.get("/consent/{session_id}", response_class=HTMLResponse)
async def consent_page(request: Request, session_id: str):
    return templates.TemplateResponse("consent.html", {"request": request, "session_id": session_id})

@app.get("/student-details/{session_id}", response_class=HTMLResponse)
async def student_details_page(request: Request, session_id: str):
    config = survey_configs["default"]
    return templates.TemplateResponse("student_details.html", {
        "request": request, 
        "session_id": session_id,
        "allow_school_change": config["allow_school_change"],
        "default_school": config["default_school"]
    })

@app.post("/submit-details/")
async def submit_details(
    session_id: str = Form(...),
    full_name: str = Form(...),
    dob: str = Form(...),
    grade: str = Form(...),
    school: str = Form(None)
):
    if session_id not in session_db:
        session_db[session_id] = {"max_q": 0}
        
    session_db[session_id]["student_info"] = {
        "full_name": full_name, "dob": dob, "grade": grade, "school": school
    }
    return RedirectResponse(url=f"/instructions/{session_id}", status_code=303)

@app.get("/instructions/{session_id}", response_class=HTMLResponse)
async def instructions(request: Request, session_id: str):
    return templates.TemplateResponse("instructions.html", {"request": request, "session_id": session_id})

@app.get("/question/{session_id}/{q_id}", response_class=HTMLResponse)
async def get_question(request: Request, session_id: str, q_id: int):
    if session_id not in session_db:
        session_db[session_id] = {"max_q": 0}
        
    max_progress = session_db[session_id].get("max_q", 0)
    
    # Enforce forward navigation only. Cannot skip ahead.
    if q_id > max_progress:
        return RedirectResponse(url=f"/question/{session_id}/{max_progress}")
    
    saved_image = session_db[session_id].get("uploaded_image", "")
    saved_answer = session_db[session_id].get(f"q_{q_id}_answer", None)
    
    config = survey_configs["default"]
    
    # TIMER LOGIC: Start/Pause/Resume
    timer_state = "running"
    time_to_send = 0
    
    if q_id == 1 and "end_time" not in session_db[session_id] and "remaining_time" not in session_db[session_id]:
        session_db[session_id]["end_time"] = (time.time() + (config["time_limit_minutes"] * 60)) * 1000 
        
    # Pause on Q10 (Instructions/Sample)
    if q_id == 10: 
        if "end_time" in session_db[session_id]:
            remaining = session_db[session_id]["end_time"] - (time.time() * 1000)
            session_db[session_id]["remaining_time"] = max(0, remaining)
            del session_db[session_id]["end_time"]
        timer_state = "paused"
        time_to_send = session_db[session_id].get("remaining_time", 0)
        
    # Running for all others (Q1-9, Q11-20)
    elif q_id > 0:
        if "remaining_time" in session_db[session_id] and "end_time" not in session_db[session_id]:
            session_db[session_id]["end_time"] = (time.time() * 1000) + session_db[session_id]["remaining_time"]
            del session_db[session_id]["remaining_time"]
        timer_state = "running"
        time_to_send = session_db[session_id].get("end_time", 0)
    
    return templates.TemplateResponse(
        "next_question.html", 
        {
            "request": request, 
            "session_id": session_id, 
            "q_id": q_id,
            "saved_image": saved_image,
            "saved_answer": json.dumps(saved_answer) if saved_answer else "null",
            "time_to_send": time_to_send,
            "timer_state": timer_state
        }
    )

@app.post("/submit_answer/")
async def submit_answer(
    session_id: str = Form(...), 
    q_id: int = Form(...), 
    answer_data: str = Form(...),
    image_data: str = Form(None)
):
    if session_id not in session_db:
        session_db[session_id] = {"max_q": 0}
        
    session_db[session_id][f"q_{q_id}_answer"] = json.loads(answer_data) if answer_data else None
    
    if image_data:
        session_db[session_id]["uploaded_image"] = image_data
    
    current_max = session_db[session_id].get("max_q", 0)
    if q_id == current_max:
        session_db[session_id]["max_q"] = q_id + 1
        
    #The quiz now ends at Question 30 
    if q_id == 30:
        return RedirectResponse(url=f"/finish_survey/{session_id}", status_code=303)
        
    next_q = q_id + 1
    return RedirectResponse(url=f"/question/{session_id}/{next_q}", status_code=303)


# Handles the very final submission and renders the thank you page.
@app.get("/finish_survey/{session_id}", response_class=HTMLResponse)
async def finish_survey(request: Request, session_id: str):
    """Marks session complete in background and shows thank you page."""
    if session_id in session_db:
        session_db[session_id]["complete"] = True
        session_db[session_id]["finish_time"] = time.time()
        # You could also trigger a data dump to your PostgreSQL DB here
        
    return templates.TemplateResponse("submitted.html", {"request": request})

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)