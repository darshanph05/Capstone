
Prerequisites & Installation
Ensure you have Python 3.7+ installed. You will need to install the required Python packages.

Open your terminal and run:

pip install fastapi uvicorn jinja2 python-multipart

Step 1: Open your terminal and navigate to your project folder:

Bash
cd path/to/CAPSTONE QUAN USER VIEW 26:3

Step 2: Start the FastAPI server using Python:

Bash
python3 web.py
(You should see terminal output confirming Uvicorn running on http://0.0.0.0:8000)

Step 3: Open your web browser (Chrome, Safari, Edge, etc.) and go to the following link to start the Student Survey view:

👉 http://localhost:8000/take-survey/test-survey-123

(Note: test-survey-123 is a mock session ID used for testing).