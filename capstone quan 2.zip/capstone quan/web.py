
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import uvicorn
import json
import uuid

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

session_db = {}


@app.get("/", response_class=HTMLResponse)
async def landing_page(request: Request):
    """Landing page - now just an Admin entry button"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/admin-login", response_class=HTMLResponse)
async def admin_login_page(request: Request):
    """Admin login form"""
    return templates.TemplateResponse("admin_login.html", {"request": request})

@app.post("/admin-login")
async def process_admin_login(email: str = Form(...), password: str = Form(...)):
    """Process login and send to dashboard (Authentication logic goes here later)"""
    # For now, immediately redirect to the dashboard
    return RedirectResponse(url="/dashboard", status_code=303)

@app.get("/admin-register", response_class=HTMLResponse)
async def admin_register_page(request: Request):
    """Admin account creation form"""
    return templates.TemplateResponse("admin_register.html", {"request": request})

@app.post("/admin-register")
async def process_admin_register(email: str = Form(...), password: str = Form(...), confirm_password: str = Form(...)):
    """Process new account and send back to login"""
    # Later: Check if passwords match, save to database
    return RedirectResponse(url="/admin-login", status_code=303)

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    """Main admin dashboard for building surveys"""
    return templates.TemplateResponse("dashboard.html", {"request": request})

# EXISTING SURVEY ROUTES (Kept for later use) 

@app.get("/question/{q_id}", response_class=HTMLResponse)
async def get_question_start(request: Request, q_id: int):
    session_id = str(uuid.uuid4())
    return RedirectResponse(url=f"/question/{session_id}/{q_id}", status_code=303)

@app.get("/question/{session_id}/{q_id}", response_class=HTMLResponse)
async def get_question(request: Request, session_id: str, q_id: int):
    if session_id not in session_db:
        session_db[session_id] = {"current_q": 1}
    current_progress = session_db[session_id].get("current_q", 1)
    if q_id < current_progress:
        return RedirectResponse(url=f"/question/{session_id}/{current_progress}")
    
    return templates.TemplateResponse("next_question.html", {"request": request, "session_id": session_id, "q_id": q_id})

@app.post("/submit_answer/")
async def submit_answer(session_id: str = Form(...), q_id: int = Form(...), answer_data: str = Form(...)):
    if session_id not in session_db:
        session_db[session_id] = {}
    session_db[session_id][f"q_{q_id}_answer"] = json.loads(answer_data) if answer_data else None
    next_q = q_id + 1
    session_db[session_id]["current_q"] = next_q
    return RedirectResponse(url=f"/question/{session_id}/{next_q}", status_code=303)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
