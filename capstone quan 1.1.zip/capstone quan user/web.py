from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import uvicorn
import json
import uuid
import time # Imported to handle the timer

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

session_db = {}
surveys_db = {}
survey_configs = {
    "default": {
        "allow_school_change": False, # Change to True to test the unlocked state
        "default_school": "Ambience Public School"
    }
}

# --- ADMIN ROUTES ---
@app.get("/", response_class=HTMLResponse)
async def landing_page(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/admin-login", response_class=HTMLResponse)
async def admin_login_page(request: Request):
    return templates.TemplateResponse("admin_login.html", {"request": request})

@app.post("/admin-login")
async def process_admin_login():
    return RedirectResponse(url="/dashboard", status_code=303)

@app.get("/admin-register", response_class=HTMLResponse)
async def admin_register_page(request: Request):
    return templates.TemplateResponse("admin_register.html", {"request": request})

@app.post("/admin-register")
async def process_admin_register():
    return RedirectResponse(url="/admin-login", status_code=303)

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.post("/api/save_survey")
async def save_survey(request: Request):
    data = await request.json()
    survey_id = str(uuid.uuid4())[:8] 
    surveys_db[survey_id] = data
    base_url = str(request.base_url).rstrip('/')
    return JSONResponse(content={"status": "success", "survey_id": survey_id, "link": f"{base_url}/take-survey/{survey_id}"})


# --- STUDENT SURVEY FLOW ---

@app.get("/take-survey/{survey_id}")
async def take_survey(request: Request, survey_id: str):
    session_id = str(uuid.uuid4())
    session_db[session_id] = {"max_q": 0, "current_q": 0, "survey_id": survey_id}
    return RedirectResponse(url=f"/consent/{session_id}", status_code=303)

@app.get("/consent/{session_id}", response_class=HTMLResponse)
async def consent_page(request: Request, session_id: str):
    return templates.TemplateResponse("consent.html", {"request": request, "session_id": session_id})

# NEW ROUTE: The details page right after consent
@app.get("/student-details/{session_id}", response_class=HTMLResponse)
async def student_details_page(request: Request, session_id: str):
    # Fetch the admin's configuration for this survey
    config = survey_configs["default"]
    
    return templates.TemplateResponse("student_details.html", {
        "request": request, 
        "session_id": session_id,
        "allow_school_change": config["allow_school_change"],
        "default_school": config["default_school"]
    })

# Saves the details and moves to instructions
@app.post("/submit-details/")
async def submit_details(
    session_id: str = Form(...),
    full_name: str = Form(...),
    dob: str = Form(...),
    grade: str = Form(...),
    school: str = Form(None) # Might be None if the field is locked/disabled
):
    if session_id not in session_db:
        session_db[session_id] = {"max_q": 0}
        
    # Save student data to their session
    session_db[session_id]["student_info"] = {
        "full_name": full_name,
        "dob": dob,
        "grade": grade,
        "school": school
    }
    
    # Push to instructions
    return RedirectResponse(url=f"/instructions/{session_id}", status_code=303)

@app.get("/instructions/{session_id}", response_class=HTMLResponse)
async def instructions(request: Request, session_id: str):
    return templates.TemplateResponse("instructions.html", {"request": request, "session_id": session_id})

@app.get("/question/{session_id}/{q_id}", response_class=HTMLResponse)
async def get_question(request: Request, session_id: str, q_id: int):
    if session_id not in session_db:
        session_db[session_id] = {"max_q": 0}
        
    max_progress = session_db[session_id].get("max_q", 0)
    
    if q_id > max_progress:
        return RedirectResponse(url=f"/question/{session_id}/{max_progress}")
    
    saved_image = session_db[session_id].get("uploaded_image", "")
    saved_answer = session_db[session_id].get(f"q_{q_id}_answer", None)
    
    if q_id == 1 and "start_time" not in session_db[session_id]:
        session_db[session_id]["start_time"] = time.time() * 1000 
        
    start_time = session_db[session_id].get("start_time", 0)
    
    return templates.TemplateResponse(
        "next_question.html", 
        {
            "request": request, 
            "session_id": session_id, 
            "q_id": q_id,
            "saved_image": saved_image,
            "saved_answer": json.dumps(saved_answer) if saved_answer else "null",
            "start_time": start_time
        }
    )

@app.post("/submit_answer/")
async def submit_answer(
    session_id: str = Form(...), 
    q_id: int = Form(...), 
    answer_data: str = Form(...),
    image_data: str = Form(None)
):
    if session_id not in session_db:
        session_db[session_id] = {"max_q": 0}
        
    session_db[session_id][f"q_{q_id}_answer"] = json.loads(answer_data) if answer_data else None
    
    if image_data:
        session_db[session_id]["uploaded_image"] = image_data
    
    current_max = session_db[session_id].get("max_q", 0)
    if q_id == current_max:
        session_db[session_id]["max_q"] = q_id + 1
        
    next_q = q_id + 1
    
    return RedirectResponse(url=f"/question/{session_id}/{next_q}", status_code=303)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)